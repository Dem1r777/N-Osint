#!/usr/bin/env python3
"""
N-OSINT — Терминальный OSINT-инструмент для поиска человека по никнейму
в соцсетях, мессенджерах, игровых и IT-платформах мира (аналог Sherlock).

Запуск:
    python n_osint.py                  # Интерактивный TUI режим
    python n_osint.py <username>       # Быстрый поиск по всем платформам
"""

import sys
from n_osint.cli import main

if __name__ == "__main__":
    sys.exit(main())
