@echo off
chcp 65001 >nul
title N-OSINT // Global Username Reconnaissance

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Python не найден в PATH. Пожалуйста, установите Python 3.9+ с https://www.python.org/downloads/
    echo     При установке обязательно отметьте галочку "Add python.exe to PATH".
    pause
    exit /b 1
)

python -c "import rich, httpx" >nul 2>nul
if %errorlevel% neq 0 (
    echo [*] Установка необходимых библиотек (rich, httpx, aiohttp)...
    python -m pip install -r requirements.txt
)

python n_osint.py %*
pause
