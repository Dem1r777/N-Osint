"""
Database of global social networks, messengers, gaming, developer, creative,
and regional platforms for N-OSINT username reconnaissance.

Each site entry supports:
- url: Public profile URL template with `{}` placeholder for username
- url_probe: Optional custom URL used for HTTP probing (e.g., public API / syndication / oEmbed)
- category: Platform category for filtering & TUI grouping
- error_type: Detection method:
    * "status_code"  - HTTP 200 means found, 404/4xx means not found
    * "message"      - Check HTML response text for `error_msg` (and optionally `found_msg`)
    * "response_url" - Check if request was redirected to a login/error URL
- error_msg: String or list of strings indicating the profile does NOT exist
- found_msg: Optional string or list of strings that MUST be present for a positive match
- regex_check: Optional regex pattern validating whether a username is legal on this platform
- headers: Optional site-specific HTTP headers
"""

from typing import Dict, Any, List

CATEGORIES: Dict[str, str] = {
    "social": "Social Networks",
    "messengers": "Messengers",
    "video": "Video & Streams",
    "gaming": "Gaming",
    "dev": "IT & Coding",
    "professional": "Career & Business",
    "creative": "Art & Design",
    "music": "Music & Audio",
    "blogs": "Blogs & Forums",
    "cis": "CIS Services",
    "asia": "Asian Platforms",
    "finance": "Freelance & Crypto",
    "hobbies": "Hobbies & Lifestyle",
}

SITES_DB: Dict[str, Dict[str, Any]] = {
    # =========================================================================
    # СОЦСЕТИ (GLOBAL SOCIAL NETWORKS)
    # =========================================================================
    "X (Twitter)": {
        "category": "social",
        "url": "https://x.com/{}",
        "url_probe": "https://syndication.twitter.com/srv/timeline-profile/screen-name/{}",
        "error_type": "message",
        "error_msg": ["This account doesn’t exist", "page doesn’t exist", "\"results\":[]", "Error 404"],
        "found_msg": ["timeline-Body", "screen_name", "data-testid"],
        "regex_check": r"^[A-Za-z0-9_]{1,15}$",
    },
    "Instagram": {
        "category": "social",
        "url": "https://www.instagram.com/{}/",
        "url_probe": "https://www.instagram.com/{}/",
        "error_type": "message",
        "error_msg": [
            "Sorry, this page isn't available.",
            "The link you followed may be broken",
            "Страница не найдена",
        ],
        "found_msg": ["og:title", "instagram.com/"],
        "regex_check": r"^[A-Za-z0-9._]{1,30}$",
    },
    "TikTok": {
        "category": "social",
        "url": "https://www.tiktok.com/@{}",
        "error_type": "message",
        "error_msg": [
            "Couldn't find this account",
            "\"statusCode\":10202",
            "\"statusCode\":10221",
            "\"userInfo\":{}",
        ],
        "found_msg": ["\"uniqueId\":\"", "tiktok.com/@"],
        "regex_check": r"^[A-Za-z0-9._]{2,24}$",
    },
    "Threads": {
        "category": "social",
        "url": "https://www.threads.net/@{}",
        "error_type": "message",
        "error_msg": [
            "Sorry, this page isn't available",
            "The link you followed may be broken",
        ],
        "found_msg": ["og:title", "@"],
        "regex_check": r"^[A-Za-z0-9._]{1,30}$",
    },
    "Facebook": {
        "category": "social",
        "url": "https://www.facebook.com/{}",
        "error_type": "message",
        "error_msg": [
            "This content isn't available right now",
            "Page Not Found",
            "Этот контент сейчас недоступен",
        ],
        "regex_check": r"^[A-Za-z0-9.]{5,50}$",
    },
    "Pinterest": {
        "category": "social",
        "url": "https://www.pinterest.com/{}/",
        "url_probe": "https://www.pinterest.com/{}/",
        "error_type": "message",
        "error_msg": ["User not found", "show_error=true"],
        "regex_check": r"^[A-Za-z0-9_]{3,30}$",
    },
    "Snapchat": {
        "category": "social",
        "url": "https://www.snapchat.com/add/{}",
        "error_type": "status_code",
        "error_msg": ["Sorry, This content was not found"],
        "regex_check": r"^[A-Za-z][A-Za-z0-9._-]{2,14}$",
    },
    "Bluesky": {
        "category": "social",
        "url": "https://bsky.app/profile/{}.bsky.social",
        "url_probe": "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor={}.bsky.social",
        "error_type": "status_code",
        "error_msg": ["Profile not found", "InvalidRequest"],
    },
    "Mastodon (mastodon.social)": {
        "category": "social",
        "url": "https://mastodon.social/@{}",
        "url_probe": "https://mastodon.social/api/v1/accounts/lookup?acct={}",
        "error_type": "status_code",
    },
    "Mastodon (fosstodon.org)": {
        "category": "social",
        "url": "https://fosstodon.org/@{}",
        "url_probe": "https://fosstodon.org/api/v1/accounts/lookup?acct={}",
        "error_type": "status_code",
    },
    "Mastodon (mstdn.social)": {
        "category": "social",
        "url": "https://mstdn.social/@{}",
        "url_probe": "https://mstdn.social/api/v1/accounts/lookup?acct={}",
        "error_type": "status_code",
    },
    "Reddit": {
        "category": "social",
        "url": "https://www.reddit.com/user/{}",
        "url_probe": "https://www.reddit.com/user/{}/about.json",
        "error_type": "message",
        "error_msg": ["\"error\": 404", "page not found", "\"is_suspended\": true"],
        "found_msg": ["\"kind\": \"t2\""],
        "regex_check": r"^[A-Za-z0-9_-]{3,20}$",
    },
    "Tumblr": {
        "category": "social",
        "url": "https://{}.tumblr.com",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9-]{1,32}$",
    },
    "Truth Social": {
        "category": "social",
        "url": "https://truthsocial.com/@{}",
        "error_type": "status_code",
    },
    "Gab": {
        "category": "social",
        "url": "https://gab.com/{}",
        "error_type": "status_code",
    },
    "Minds": {
        "category": "social",
        "url": "https://www.minds.com/{}/",
        "error_type": "message",
        "error_msg": ["Channel not found", "404"],
    },
    "MeWe": {
        "category": "social",
        "url": "https://mewe.com/i/{}",
        "error_type": "status_code",
    },
    "Gettr": {
        "category": "social",
        "url": "https://gettr.com/user/{}",
        "url_probe": "https://api.gettr.com/s/uinf/{}",
        "error_type": "status_code",
    },
    "Clubhouse": {
        "category": "social",
        "url": "https://www.clubhouse.com/@{}",
        "error_type": "status_code",
    },
    "Linktree": {
        "category": "social",
        "url": "https://linktr.ee/{}",
        "error_type": "message",
        "error_msg": ["The page you’re looking for doesn’t exist", "404"],
        "regex_check": r"^[A-Za-z0-9._-]{2,30}$",
    },
    "Carrd": {
        "category": "social",
        "url": "https://{}.carrd.co",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9-]{3,30}$",
    },
    "About.me": {
        "category": "social",
        "url": "https://about.me/{}",
        "error_type": "status_code",
    },
    "Bento.me": {
        "category": "social",
        "url": "https://bento.me/{}",
        "error_type": "status_code",
    },
    "Taplink": {
        "category": "social",
        "url": "https://taplink.cc/{}",
        "error_type": "status_code",
    },
    "Beacons.ai": {
        "category": "social",
        "url": "https://beacons.ai/{}",
        "error_type": "status_code",
    },
    "Solo.to": {
        "category": "social",
        "url": "https://solo.to/{}",
        "error_type": "status_code",
    },
    "Bio.link": {
        "category": "social",
        "url": "https://bio.link/{}",
        "error_type": "status_code",
    },
    "Gravatar": {
        "category": "social",
        "url": "https://en.gravatar.com/{}",
        "url_probe": "https://en.gravatar.com/{}.json",
        "error_type": "status_code",
    },
    "Ask.fm": {
        "category": "social",
        "url": "https://ask.fm/{}",
        "error_type": "message",
        "error_msg": ["Well, apparently not anymore", "Page not found"],
    },
    "Tellonym": {
        "category": "social",
        "url": "https://tellonym.me/{}",
        "error_type": "status_code",
    },
    "NGL.link": {
        "category": "social",
        "url": "https://ngl.link/{}",
        "error_type": "message",
        "error_msg": ["Could not find user", "Page not found"],
    },
    "SpaceHey": {
        "category": "social",
        "url": "https://spacehey.com/{}",
        "error_type": "message",
        "error_msg": ["404 - Page not found"],
    },

    # =========================================================================
    # МЕССЕНДЖЕРЫ И ЧАТЫ (MESSENGERS & CHAT)
    # =========================================================================
    "Telegram": {
        "category": "messengers",
        "url": "https://t.me/{}",
        "error_type": "message",
        "error_msg": [
            "If you have <strong>Telegram</strong>, you can contact <a class=\"tgme_username_link\"",
            "tgme_icon_user",
        ],
        "found_msg": ["tgme_page_title", "tgme_page_extra"],
        "regex_check": r"^[A-Za-z][A-Za-z0-9_]{4,31}$",
    },
    "Discord (Invite / Vanity)": {
        "category": "messengers",
        "url": "https://discord.com/invite/{}",
        "url_probe": "https://discord.com/api/v9/invites/{}",
        "error_type": "message",
        "error_msg": ["Unknown Invite", "\"code\": 10006"],
    },
    "Keybase": {
        "category": "messengers",
        "url": "https://keybase.io/{}",
        "url_probe": "https://keybase.io/_/api/1.0/user/lookup.json?usernames={}",
        "error_type": "message",
        "error_msg": ["\"them\":[null]", "\"status\":{\"code\":100"],
        "regex_check": r"^[A-Za-z0-9_]{1,16}$",
    },
    "Matrix (matrix.to)": {
        "category": "messengers",
        "url": "https://matrix.to/#/@{}:matrix.org",
        "url_probe": "https://matrix.org/_matrix/client/v3/profile/@{}:matrix.org",
        "error_type": "status_code",
    },
    "ICQ / VK Teams": {
        "category": "messengers",
        "url": "https://icq.im/{}",
        "error_type": "message",
        "error_msg": ["User not found", "404"],
    },
    "Session / Oxen": {
        "category": "messengers",
        "url": "https://hub.docker.com/u/{}",
        "error_type": "status_code",
    },
    " Kik": {
        "category": "messengers",
        "url": "https://kik.me/{}",
        "error_type": "message",
        "error_msg": ["Not Found", "is not on Kik"],
    },

    # =========================================================================
    # ПРОФЕССИОНАЛЬНЫЕ СЕТИ И КАРЬЕРА (PROFESSIONAL & BUSINESS)
    # =========================================================================
    "LinkedIn": {
        "category": "professional",
        "url": "https://www.linkedin.com/in/{}",
        "error_type": "status_code",
        "error_msg": ["Page not found", "This page doesn’t exist", "authwall"],
        "regex_check": r"^[A-Za-z0-9-]{3,100}$",
    },
    "ProductHunt": {
        "category": "professional",
        "url": "https://www.producthunt.com/@{}",
        "error_type": "message",
        "error_msg": ["Page not found", "We seem to have lost this page"],
    },
    "IndieHackers": {
        "category": "professional",
        "url": "https://www.indiehackers.com/{}",
        "error_type": "status_code",
    },
    "Crunchbase": {
        "category": "professional",
        "url": "https://www.crunchbase.com/person/{}",
        "error_type": "status_code",
    },
    "Wellfound (AngelList)": {
        "category": "professional",
        "url": "https://wellfound.com/u/{}",
        "error_type": "status_code",
    },
    "Polywork": {
        "category": "professional",
        "url": "https://www.polywork.com/{}",
        "error_type": "status_code",
    },
    "Read.cv": {
        "category": "professional",
        "url": "https://read.cv/{}",
        "error_type": "status_code",
    },
    "Peerlist": {
        "category": "professional",
        "url": "https://peerlist.io/{}",
        "error_type": "status_code",
    },
    "SlideShare": {
        "category": "professional",
        "url": "https://www.slideshare.net/{}",
        "error_type": "status_code",
    },
    "SpeakerDeck": {
        "category": "professional",
        "url": "https://speakerdeck.com/{}",
        "error_type": "status_code",
    },
    "ResearchGate": {
        "category": "professional",
        "url": "https://www.researchgate.net/profile/{}",
        "error_type": "status_code",
    },
    "Academia.edu": {
        "category": "professional",
        "url": "https://independent.academia.edu/{}",
        "error_type": "status_code",
    },

    # =========================================================================
    # ИГРЫ И КИБЕРСПОРТ (GAMING & ESPORTS)
    # =========================================================================
    "Steam (Custom ID)": {
        "category": "gaming",
        "url": "https://steamcommunity.com/id/{}",
        "error_type": "message",
        "error_msg": [
            "The specified profile could not be found",
            "Указанный профиль не может быть найден",
            "<title>Steam Community :: Error</title>",
        ],
        "found_msg": ["actual_persona_name"],
        "regex_check": r"^[A-Za-z0-9_-]{2,32}$",
    },
    "Steam Group": {
        "category": "gaming",
        "url": "https://steamcommunity.com/groups/{}",
        "error_type": "message",
        "error_msg": [
            "No group could be retrieved for the given URL",
            "<title>Steam Community :: Error</title>",
        ],
    },
    "Roblox": {
        "category": "gaming",
        "url": "https://www.roblox.com/user.aspx?username={}",
        "url_probe": "https://users.roblox.com/v1/users/search?keyword={}&limit=10",
        "error_type": "message",
        "error_msg": ["\"data\":[]", "Page cannot be found", "TooManyRequests"],
        "regex_check": r"^[A-Za-z0-9_]{3,20}$",
    },
    "Chess.com": {
        "category": "gaming",
        "url": "https://www.chess.com/member/{}",
        "url_probe": "https://api.chess.com/pub/player/{}",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9_-]{3,25}$",
    },
    "Lichess": {
        "category": "gaming",
        "url": "https://lichess.org/@/{}",
        "url_probe": "https://lichess.org/api/user/{}",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9_-]{2,20}$",
    },
    "FACEIT": {
        "category": "gaming",
        "url": "https://www.faceit.com/en/players/{}",
        "url_probe": "https://api.faceit.com/users/v1/nicknames/{}",
        "error_type": "status_code",
    },
    "osu!": {
        "category": "gaming",
        "url": "https://osu.ppy.sh/users/{}",
        "error_type": "status_code",
    },
    "Minecraft (NameMC / Ashcon)": {
        "category": "gaming",
        "url": "https://namemc.com/profile/{}",
        "url_probe": "https://api.ashcon.app/mojang/v2/user/{}",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9_]{3,16}$",
    },
    "PSNProfiles (PlayStation)": {
        "category": "gaming",
        "url": "https://psnprofiles.com/{}",
        "error_type": "response_url",
        "error_msg": ["psnprofiles.com/?psnId="],
        "regex_check": r"^[A-Za-z][A-Za-z0-9_-]{2,15}$",
    },
    "XboxGamertag": {
        "category": "gaming",
        "url": "https://xboxgamertag.com/search/{}",
        "error_type": "status_code",
    },
    "Speedrun.com": {
        "category": "gaming",
        "url": "https://www.speedrun.com/users/{}",
        "url_probe": "https://www.speedrun.com/api/v1/users/{}",
        "error_type": "status_code",
    },
    "Itch.io": {
        "category": "gaming",
        "url": "https://{}.itch.io",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9_-]{2,30}$",
    },
    "GameJolt": {
        "category": "gaming",
        "url": "https://gamejolt.com/@{}",
        "url_probe": "https://gamejolt.com/site-api/web/profile/@{}",
        "error_type": "message",
        "error_msg": ["\"user\":null"],
    },
    "Newgrounds": {
        "category": "gaming",
        "url": "https://{}.newgrounds.com",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9_-]{3,25}$",
    },
    "Modrinth": {
        "category": "gaming",
        "url": "https://modrinth.com/user/{}",
        "url_probe": "https://api.modrinth.com/v2/user/{}",
        "error_type": "status_code",
    },
    "CurseForge": {
        "category": "gaming",
        "url": "https://www.curseforge.com/members/{}",
        "error_type": "status_code",
    },
    "NexusMods": {
        "category": "gaming",
        "url": "https://next.nexusmods.com/profile/{}",
        "error_type": "status_code",
    },
    "Backloggd": {
        "category": "gaming",
        "url": "https://www.backloggd.com/u/{}/",
        "error_type": "status_code",
    },
    "GOG": {
        "category": "gaming",
        "url": "https://www.gog.com/u/{}",
        "error_type": "status_code",
    },
    "TETR.IO": {
        "category": "gaming",
        "url": "https://ch.tetr.io/u/{}",
        "url_probe": "https://ch.tetr.io/api/users/{}",
        "error_type": "message",
        "error_msg": ["\"success\":false"],
    },

    # =========================================================================
    # ВИДЕО И СТРИМИНГ (VIDEO & STREAMING)
    # =========================================================================
    "YouTube": {
        "category": "video",
        "url": "https://www.youtube.com/@{}",
        "error_type": "status_code",
        "error_msg": ["404 Not Found", "This page isn't available"],
        "regex_check": r"^[A-Za-z0-9._-]{3,30}$",
    },
    "Twitch": {
        "category": "video",
        "url": "https://www.twitch.tv/{}",
        "url_probe": "https://m.twitch.tv/{}",
        "error_type": "message",
        "error_msg": [
            "Sorry. Unless you've got a time machine",
            "content is unavailable",
        ],
        "found_msg": ["twitch.tv/"],
        "regex_check": r"^[A-Za-z0-9_]{4,25}$",
    },
    "Kick": {
        "category": "video",
        "url": "https://kick.com/{}",
        "url_probe": "https://kick.com/api/v2/channels/{}",
        "error_type": "status_code",
    },
    "Rumble": {
        "category": "video",
        "url": "https://rumble.com/user/{}",
        "error_type": "status_code",
    },
    "Vimeo": {
        "category": "video",
        "url": "https://vimeo.com/{}",
        "error_type": "status_code",
    },
    "Dailymotion": {
        "category": "video",
        "url": "https://www.dailymotion.com/{}",
        "url_probe": "https://api.dailymotion.com/user/{}",
        "error_type": "status_code",
    },
    "Trovo": {
        "category": "video",
        "url": "https://trovo.live/s/{}",
        "error_type": "status_code",
    },
    "Coub": {
        "category": "video",
        "url": "https://coub.com/{}",
        "error_type": "status_code",
    },
    "Likee": {
        "category": "video",
        "url": "https://likee.video/@{}",
        "error_type": "message",
        "error_msg": ["Page not found", "404"],
    },
    "Bigo Live": {
        "category": "video",
        "url": "https://www.bigo.tv/{}",
        "error_type": "message",
        "error_msg": ["404", "User does not exist"],
    },

    # =========================================================================
    # IT, КОДИНГ И ИНФОБЕЗ (CODING, TECH & CYBERSECURITY)
    # =========================================================================
    "GitHub": {
        "category": "dev",
        "url": "https://github.com/{}",
        "url_probe": "https://api.github.com/users/{}",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9](?:[A-Za-z0-9]|-(?=[A-Za-z0-9])){0,38}$",
    },
    "GitLab": {
        "category": "dev",
        "url": "https://gitlab.com/{}",
        "url_probe": "https://gitlab.com/api/v4/users?username={}",
        "error_type": "message",
        "error_msg": ["[]"],
        "found_msg": ["\"username\":"],
    },
    "Bitbucket": {
        "category": "dev",
        "url": "https://bitbucket.org/{}/",
        "error_type": "status_code",
    },
    "Codeberg": {
        "category": "dev",
        "url": "https://codeberg.org/{}",
        "error_type": "status_code",
    },
    "Gitea": {
        "category": "dev",
        "url": "https://gitea.com/{}",
        "error_type": "status_code",
    },
    "SourceForge": {
        "category": "dev",
        "url": "https://sourceforge.net/u/{}/profile",
        "error_type": "status_code",
    },
    "HuggingFace": {
        "category": "dev",
        "url": "https://huggingface.co/{}",
        "error_type": "status_code",
    },
    "Kaggle": {
        "category": "dev",
        "url": "https://www.kaggle.com/{}",
        "error_type": "status_code",
    },
    "LeetCode": {
        "category": "dev",
        "url": "https://leetcode.com/u/{}/",
        "error_type": "status_code",
    },
    "Codeforces": {
        "category": "dev",
        "url": "https://codeforces.com/profile/{}",
        "url_probe": "https://codeforces.com/api/user.info?handles={}",
        "error_type": "message",
        "error_msg": ["\"status\":\"FAILED\""],
        "found_msg": ["\"status\":\"OK\""],
    },
    "Codewars": {
        "category": "dev",
        "url": "https://www.codewars.com/users/{}",
        "url_probe": "https://www.codewars.com/api/v1/users/{}",
        "error_type": "status_code",
    },
    "HackerRank": {
        "category": "dev",
        "url": "https://www.hackerrank.com/profile/{}",
        "error_type": "status_code",
    },
    "AtCoder": {
        "category": "dev",
        "url": "https://atcoder.jp/users/{}",
        "error_type": "status_code",
    },
    "TopCoder": {
        "category": "dev",
        "url": "https://profiles.topcoder.com/{}",
        "error_type": "status_code",
    },
    "Dev.to": {
        "category": "dev",
        "url": "https://dev.to/{}",
        "error_type": "status_code",
    },
    "Hashnode": {
        "category": "dev",
        "url": "https://hashnode.com/@{}",
        "error_type": "status_code",
    },
    "Replit": {
        "category": "dev",
        "url": "https://replit.com/@{}",
        "error_type": "status_code",
    },
    "CodePen": {
        "category": "dev",
        "url": "https://codepen.io/{}",
        "error_type": "status_code",
    },
    "JSFiddle": {
        "category": "dev",
        "url": "https://jsfiddle.net/user/{}/",
        "error_type": "status_code",
    },
    "StackBlitz": {
        "category": "dev",
        "url": "https://stackblitz.com/@{}",
        "error_type": "status_code",
    },
    "Docker Hub": {
        "category": "dev",
        "url": "https://hub.docker.com/u/{}",
        "url_probe": "https://hub.docker.com/v2/users/{}/",
        "error_type": "status_code",
    },
    "PyPI": {
        "category": "dev",
        "url": "https://pypi.org/user/{}/",
        "error_type": "status_code",
    },
    "npm": {
        "category": "dev",
        "url": "https://www.npmjs.com/~{}",
        "error_type": "status_code",
    },
    "Crates.io (Rust)": {
        "category": "dev",
        "url": "https://crates.io/users/{}",
        "url_probe": "https://crates.io/api/v1/users/{}",
        "error_type": "status_code",
    },
    "RubyGems": {
        "category": "dev",
        "url": "https://rubygems.org/profiles/{}",
        "error_type": "status_code",
    },
    "Packagist (PHP)": {
        "category": "dev",
        "url": "https://packagist.org/users/{}/",
        "error_type": "status_code",
    },
    "NuGet": {
        "category": "dev",
        "url": "https://www.nuget.org/profiles/{}",
        "error_type": "status_code",
    },
    "Launchpad": {
        "category": "dev",
        "url": "https://launchpad.net/~{}",
        "error_type": "status_code",
    },
    "AUR (Arch Linux)": {
        "category": "dev",
        "url": "https://aur.archlinux.org/account/{}",
        "error_type": "status_code",
    },
    "HackerNews (YCombinator)": {
        "category": "dev",
        "url": "https://news.ycombinator.com/user?id={}",
        "url_probe": "https://hacker-news.firebaseio.com/v0/user/{}.json",
        "error_type": "message",
        "error_msg": ["null"],
        "found_msg": ["\"id\":"],
    },
    "HackerOne": {
        "category": "dev",
        "url": "https://hackerone.com/{}",
        "error_type": "status_code",
    },
    "Bugcrowd": {
        "category": "dev",
        "url": "https://bugcrowd.com/{}",
        "error_type": "status_code",
    },
    "TryHackMe": {
        "category": "dev",
        "url": "https://tryhackme.com/p/{}",
        "url_probe": "https://tryhackme.com/api/user/exist/{}",
        "error_type": "message",
        "error_msg": ["\"success\":false"],
    },
    "Root-Me": {
        "category": "dev",
        "url": "https://www.root-me.org/{}",
        "error_type": "status_code",
    },
    "WakaTime": {
        "category": "dev",
        "url": "https://wakatime.com/@{}",
        "error_type": "status_code",
    },
    "Pastebin": {
        "category": "dev",
        "url": "https://pastebin.com/u/{}",
        "error_type": "status_code",
    },

    # =========================================================================
    # ДИЗАЙН, ФОТО И АРТ (ART, DESIGN & PHOTO)
    # =========================================================================
    "Behance": {
        "category": "creative",
        "url": "https://www.behance.net/{}",
        "error_type": "status_code",
    },
    "Dribbble": {
        "category": "creative",
        "url": "https://dribbble.com/{}",
        "error_type": "status_code",
    },
    "ArtStation": {
        "category": "creative",
        "url": "https://www.artstation.com/{}",
        "url_probe": "https://www.artstation.com/users/{}/quick.json",
        "error_type": "status_code",
    },
    "DeviantArt": {
        "category": "creative",
        "url": "https://www.deviantart.com/{}",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9-]{3,20}$",
    },
    "Figma": {
        "category": "creative",
        "url": "https://www.figma.com/@{}",
        "error_type": "status_code",
    },
    "Unsplash": {
        "category": "creative",
        "url": "https://unsplash.com/@{}",
        "error_type": "status_code",
    },
    "Flickr": {
        "category": "creative",
        "url": "https://www.flickr.com/people/{}/",
        "error_type": "status_code",
    },
    "500px": {
        "category": "creative",
        "url": "https://500px.com/p/{}",
        "error_type": "status_code",
    },
    "VSCO": {
        "category": "creative",
        "url": "https://vsco.co/{}/gallery",
        "error_type": "status_code",
    },
    "EyeEm": {
        "category": "creative",
        "url": "https://www.eyeem.com/u/{}",
        "error_type": "status_code",
    },
    "Imgur": {
        "category": "creative",
        "url": "https://imgur.com/user/{}",
        "url_probe": "https://api.imgur.com/account/v1/accounts/{}?client_id=546c25a59c58ad7",
        "error_type": "status_code",
    },
    "Giphy": {
        "category": "creative",
        "url": "https://giphy.com/{}",
        "error_type": "status_code",
    },
    "Tenor": {
        "category": "creative",
        "url": "https://tenor.com/users/{}",
        "error_type": "status_code",
    },
    "Sketchfab": {
        "category": "creative",
        "url": "https://sketchfab.com/{}",
        "url_probe": "https://api.sketchfab.com/v3/users?username={}",
        "error_type": "message",
        "error_msg": ["\"results\":[]"],
    },
    "Thingiverse": {
        "category": "creative",
        "url": "https://www.thingiverse.com/{}/designs",
        "error_type": "status_code",
    },
    "Printables": {
        "category": "creative",
        "url": "https://www.printables.com/@{}",
        "error_type": "status_code",
    },
    "Cara.app": {
        "category": "creative",
        "url": "https://cara.app/{}",
        "error_type": "status_code",
    },
    "Pixiv": {
        "category": "creative",
        "url": "https://www.pixiv.net/en/users/{}",
        "error_type": "status_code",
        "regex_check": r"^[0-9]+$",
    },

    # =========================================================================
    # МУЗЫКА И АУДИО (MUSIC & AUDIO)
    # =========================================================================
    "SoundCloud": {
        "category": "music",
        "url": "https://soundcloud.com/{}",
        "error_type": "status_code",
    },
    "Spotify": {
        "category": "music",
        "url": "https://open.spotify.com/user/{}",
        "error_type": "status_code",
    },
    "Bandcamp": {
        "category": "music",
        "url": "https://bandcamp.com/{}",
        "error_type": "status_code",
    },
    "Last.fm": {
        "category": "music",
        "url": "https://www.last.fm/user/{}",
        "error_type": "status_code",
    },
    "Genius": {
        "category": "music",
        "url": "https://genius.com/{}",
        "error_type": "status_code",
    },
    "Mixcloud": {
        "category": "music",
        "url": "https://www.mixcloud.com/{}/",
        "url_probe": "https://api.mixcloud.com/{}/",
        "error_type": "status_code",
    },
    "Audiomack": {
        "category": "music",
        "url": "https://audiomack.com/{}",
        "error_type": "status_code",
    },
    "ReverbNation": {
        "category": "music",
        "url": "https://www.reverbnation.com/{}",
        "error_type": "status_code",
    },
    "Discogs": {
        "category": "music",
        "url": "https://www.discogs.com/user/{}",
        "error_type": "status_code",
    },
    "RateYourMusic": {
        "category": "music",
        "url": "https://rateyourmusic.com/~{}",
        "error_type": "status_code",
    },
    "Freesound": {
        "category": "music",
        "url": "https://freesound.org/people/{}/",
        "error_type": "status_code",
    },
    "Musescore": {
        "category": "music",
        "url": "https://musescore.com/{}",
        "error_type": "status_code",
    },

    # =========================================================================
    # БЛОГИ, МЕДИА И ФОРУМЫ (BLOGS, MEDIA & FORUMS)
    # =========================================================================
    "Medium": {
        "category": "blogs",
        "url": "https://medium.com/@{}",
        "url_probe": "https://medium.com/feed/@{}",
        "error_type": "status_code",
    },
    "Substack": {
        "category": "blogs",
        "url": "https://substack.com/@{}",
        "error_type": "status_code",
    },
    "Quora": {
        "category": "blogs",
        "url": "https://www.quora.com/profile/{}",
        "error_type": "status_code",
    },
    "WordPress": {
        "category": "blogs",
        "url": "https://{}.wordpress.com",
        "error_type": "response_url",
        "error_msg": ["wordpress.com/typo/?subdomain="],
        "regex_check": r"^[A-Za-z0-9-]{3,40}$",
    },
    "Blogger": {
        "category": "blogs",
        "url": "https://{}.blogspot.com",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9-]{3,37}$",
    },
    "LiveJournal": {
        "category": "blogs",
        "url": "https://{}.livejournal.com",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9_-]{1,25}$",
    },
    "Disqus": {
        "category": "blogs",
        "url": "https://disqus.com/by/{}/",
        "error_type": "status_code",
    },
    "Wikipedia (EN)": {
        "category": "blogs",
        "url": "https://en.wikipedia.org/wiki/User:{}",
        "error_type": "status_code",
    },
    "Wikipedia (RU)": {
        "category": "blogs",
        "url": "https://ru.wikipedia.org/wiki/Участник:{}",
        "error_type": "status_code",
    },
    "Fandom": {
        "category": "blogs",
        "url": "https://community.fandom.com/wiki/User:{}",
        "error_type": "status_code",
    },
    "Slashdot": {
        "category": "blogs",
        "url": "https://slashdot.org/~{}",
        "error_type": "message",
        "error_msg": ["The user you requested does not exist"],
    },
    "DailyKos": {
        "category": "blogs",
        "url": "https://www.dailykos.com/user/{}",
        "error_type": "status_code",
    },
    "Wattpad": {
        "category": "blogs",
        "url": "https://www.wattpad.com/user/{}",
        "url_probe": "https://www.wattpad.com/api/v3/users/{}",
        "error_type": "status_code",
    },
    "Archive of Our Own (AO3)": {
        "category": "blogs",
        "url": "https://archiveofourown.org/users/{}",
        "error_type": "status_code",
    },
    "Scribd": {
        "category": "blogs",
        "url": "https://www.scribd.com/{}",
        "error_type": "status_code",
    },
    "Issuu": {
        "category": "blogs",
        "url": "https://issuu.com/{}",
        "error_type": "status_code",
    },
    "9GAG": {
        "category": "blogs",
        "url": "https://9gag.com/u/{}",
        "error_type": "status_code",
    },
    "IFunny": {
        "category": "blogs",
        "url": "https://ifunny.co/user/{}",
        "error_type": "status_code",
    },

    # =========================================================================
    # СНГ И ЛОКАЛЬНЫЕ СЕРВИСЫ (CIS & REGIONAL PLATFORMS)
    # =========================================================================
    "VK (ВКонтакте)": {
        "category": "cis",
        "url": "https://vk.com/{}",
        "error_type": "message",
        "error_msg": [
            "404 Not Found",
            "Страница удалена либо ещё не создана",
            "This page has been deleted or has not been created yet",
        ],
        "regex_check": r"^[A-Za-z0-9_.]{3,32}$",
    },
    "OK.ru (Одноклассники)": {
        "category": "cis",
        "url": "https://ok.ru/{}",
        "error_type": "status_code",
    },
    "Habr (Хабр)": {
        "category": "cis",
        "url": "https://habr.com/ru/users/{}/",
        "error_type": "status_code",
    },
    "Хабр Карьера": {
        "category": "cis",
        "url": "https://career.habr.com/{}",
        "error_type": "status_code",
    },
    "Pikabu (Пикабу)": {
        "category": "cis",
        "url": "https://pikabu.ru/@{}",
        "error_type": "status_code",
    },
    "DTF": {
        "category": "cis",
        "url": "https://dtf.ru/id/{}",
        "error_type": "status_code",
    },
    "VC.ru": {
        "category": "cis",
        "url": "https://vc.ru/id/{}",
        "error_type": "status_code",
    },
    "Boosty": {
        "category": "cis",
        "url": "https://boosty.to/{}",
        "error_type": "status_code",
    },
    "Rutube": {
        "category": "cis",
        "url": "https://rutube.ru/u/{}/",
        "error_type": "status_code",
    },
    "Дзен (Dzen)": {
        "category": "cis",
        "url": "https://dzen.ru/{}",
        "error_type": "status_code",
    },
    "TenChat": {
        "category": "cis",
        "url": "https://tenchat.ru/{}",
        "error_type": "status_code",
    },
    "Drive2.ru": {
        "category": "cis",
        "url": "https://www.drive2.ru/users/{}/",
        "error_type": "status_code",
    },
    "Shikimori": {
        "category": "cis",
        "url": "https://shikimori.one/{}",
        "error_type": "status_code",
    },
    "Ficbook (Книга Фанфиков)": {
        "category": "cis",
        "url": "https://ficbook.net/authors/{}",
        "error_type": "status_code",
    },
    "Author.Today": {
        "category": "cis",
        "url": "https://author.today/u/{}",
        "error_type": "status_code",
    },
    "Kwork": {
        "category": "cis",
        "url": "https://kwork.ru/user/{}",
        "error_type": "status_code",
    },
    "FL.ru": {
        "category": "cis",
        "url": "https://www.fl.ru/users/{}/",
        "error_type": "status_code",
    },
    "Freelance.habr": {
        "category": "cis",
        "url": "https://freelance.habr.com/freelancers/{}",
        "error_type": "status_code",
    },
    "4PDA / Trashbox": {
        "category": "cis",
        "url": "https://trashbox.ru/users/{}",
        "error_type": "status_code",
    },
    "CyberForum": {
        "category": "cis",
        "url": "https://www.cyberforum.ru/members/{}.html",
        "error_type": "status_code",
    },
    "Lolzteam (Zelenka)": {
        "category": "cis",
        "url": "https://lolz.live/{}/",
        "error_type": "status_code",
    },
    "Sports.ru": {
        "category": "cis",
        "url": "https://www.sports.ru/profile/{}/",
        "error_type": "status_code",
    },
    "StopGame": {
        "category": "cis",
        "url": "https://stopgame.ru/user/{}",
        "error_type": "status_code",
    },
    "Playground.ru": {
        "category": "cis",
        "url": "https://www.playground.ru/users/{}",
        "error_type": "status_code",
    },
    "IRecommend": {
        "category": "cis",
        "url": "https://irecommend.ru/users/{}",
        "error_type": "status_code",
    },

    # =========================================================================
    # АЗИАТСКИЕ И МЕЖДУНАРОДНЫЕ ПЛАТФОРМЫ (ASIA / GLOBAL)
    # =========================================================================
    "Gitee (China Git)": {
        "category": "asia",
        "url": "https://gitee.com/{}",
        "error_type": "status_code",
    },
    "Zhihu": {
        "category": "asia",
        "url": "https://www.zhihu.com/people/{}",
        "error_type": "status_code",
    },
    "CSDN (China Dev)": {
        "category": "asia",
        "url": "https://blog.csdn.net/{}",
        "error_type": "status_code",
    },
    "Velog (Korea Dev)": {
        "category": "asia",
        "url": "https://velog.io/@{}",
        "error_type": "status_code",
    },
    "Note.com (Japan)": {
        "category": "asia",
        "url": "https://note.com/{}",
        "error_type": "status_code",
    },
    "Qiita (Japan Dev)": {
        "category": "asia",
        "url": "https://qiita.com/{}",
        "error_type": "status_code",
    },
    "Zenn.dev (Japan Dev)": {
        "category": "asia",
        "url": "https://zenn.dev/{}",
        "error_type": "status_code",
    },
    "Hatena Blog (Japan)": {
        "category": "asia",
        "url": "https://profile.hatena.ne.jp/{}/",
        "error_type": "status_code",
    },
    "Weibo": {
        "category": "asia",
        "url": "https://weibo.com/n/{}",
        "error_type": "status_code",
    },

    # =========================================================================
    # ФРИЛАНС, ДОНАТЫ, КРИПТО И МАРКЕТЫ (FINANCE, WEB3 & COMMERCE)
    # =========================================================================
    "Patreon": {
        "category": "finance",
        "url": "https://www.patreon.com/{}",
        "error_type": "status_code",
    },
    "BuyMeACoffee": {
        "category": "finance",
        "url": "https://www.buymeacoffee.com/{}",
        "error_type": "status_code",
    },
    "Ko-fi": {
        "category": "finance",
        "url": "https://ko-fi.com/{}",
        "error_type": "response_url",
        "error_msg": ["ko-fi.com/art?"],
    },
    "Gumroad": {
        "category": "finance",
        "url": "https://{}.gumroad.com",
        "error_type": "status_code",
        "regex_check": r"^[A-Za-z0-9_-]{2,35}$",
    },
    "Fiverr": {
        "category": "finance",
        "url": "https://www.fiverr.com/{}",
        "error_type": "status_code",
    },
    "Freelancer.com": {
        "category": "finance",
        "url": "https://www.freelancer.com/u/{}",
        "error_type": "status_code",
    },
    "PeoplePerHour": {
        "category": "finance",
        "url": "https://www.peopleperhour.com/freelancer/{}",
        "error_type": "status_code",
    },
    "Etsy": {
        "category": "finance",
        "url": "https://www.etsy.com/shop/{}",
        "error_type": "status_code",
    },
    "eBay": {
        "category": "finance",
        "url": "https://www.ebay.com/usr/{}",
        "error_type": "message",
        "error_msg": ["The User ID you entered was not found", "User ID not found"],
    },
    "Poshmark": {
        "category": "finance",
        "url": "https://poshmark.com/closet/{}",
        "error_type": "status_code",
    },
    "Depop": {
        "category": "finance",
        "url": "https://www.depop.com/{}/",
        "error_type": "status_code",
    },
    "Redbubble": {
        "category": "finance",
        "url": "https://www.redbubble.com/people/{}",
        "error_type": "status_code",
    },
    "TeePublic": {
        "category": "finance",
        "url": "https://www.teepublic.com/user/{}",
        "error_type": "status_code",
    },
    "TradingView": {
        "category": "finance",
        "url": "https://www.tradingview.com/u/{}/",
        "error_type": "status_code",
    },
    "CoinMarketCap (Community)": {
        "category": "finance",
        "url": "https://coinmarketcap.com/community/profile/{}/",
        "error_type": "status_code",
    },
    "OpenSea": {
        "category": "finance",
        "url": "https://opensea.io/{}",
        "error_type": "status_code",
    },
    "Rarible": {
        "category": "finance",
        "url": "https://rarible.com/{}",
        "error_type": "status_code",
    },
    "Foundation.app": {
        "category": "finance",
        "url": "https://foundation.app/@{}",
        "error_type": "status_code",
    },
    "Liberapay": {
        "category": "finance",
        "url": "https://liberapay.com/{}",
        "error_type": "status_code",
    },
    "OpenCollective": {
        "category": "finance",
        "url": "https://opencollective.com/{}",
        "error_type": "status_code",
    },

    # =========================================================================
    # ХОББИ, КИНО, КНИГИ, АНИМЕ И СПОРТ (LIFESTYLE & HOBBIES)
    # =========================================================================
    "Letterboxd": {
        "category": "hobbies",
        "url": "https://letterboxd.com/{}/",
        "error_type": "status_code",
    },
    "MyAnimeList": {
        "category": "hobbies",
        "url": "https://myanimelist.net/profile/{}",
        "error_type": "status_code",
    },
    "AniList": {
        "category": "hobbies",
        "url": "https://anilist.co/user/{}/",
        "error_type": "status_code",
    },
    "Kitsu": {
        "category": "hobbies",
        "url": "https://kitsu.app/users/{}",
        "url_probe": "https://kitsu.app/api/edge/users?filter[slug]={}",
        "error_type": "message",
        "error_msg": ["\"data\":[]"],
    },
    "Goodreads": {
        "category": "hobbies",
        "url": "https://www.goodreads.com/{}",
        "error_type": "status_code",
    },
    "LibraryThing": {
        "category": "hobbies",
        "url": "https://www.librarything.com/profile/{}",
        "error_type": "message",
        "error_msg": ["This user doesn't exist"],
    },
    "Trakt.tv": {
        "category": "hobbies",
        "url": "https://trakt.tv/users/{}",
        "error_type": "status_code",
    },
    "Duolingo": {
        "category": "hobbies",
        "url": "https://www.duolingo.com/profile/{}",
        "url_probe": "https://www.duolingo.com/2017-06-30/users?username={}",
        "error_type": "message",
        "error_msg": ["\"users\":[]"],
    },
    "Memrise": {
        "category": "hobbies",
        "url": "https://app.memrise.com/user/{}/",
        "error_type": "status_code",
    },
    "OpenStreetMap": {
        "category": "hobbies",
        "url": "https://www.openstreetmap.org/user/{}",
        "error_type": "status_code",
    },
    "Strava": {
        "category": "hobbies",
        "url": "https://www.strava.com/athletes/{}",
        "error_type": "status_code",
    },
    "Untappd": {
        "category": "hobbies",
        "url": "https://untappd.com/user/{}",
        "error_type": "status_code",
    },
    "Geocaching": {
        "category": "hobbies",
        "url": "https://www.geocaching.com/p/default.aspx?u={}",
        "error_type": "status_code",
    },
    "Instructables": {
        "category": "hobbies",
        "url": "https://www.instructables.com/member/{}/",
        "error_type": "status_code",
    },
    "Hackaday.io": {
        "category": "hobbies",
        "url": "https://hackaday.io/{}",
        "error_type": "status_code",
    },
}


def get_sites(
    categories: List[str] = None,
    site_names: List[str] = None,
) -> Dict[str, Dict[str, Any]]:
    """Filter sites database by categories or specific site names."""
    filtered = {}
    for name, info in SITES_DB.items():
        if categories:
            cat_lower = [c.lower() for c in categories]
            if info.get("category", "").lower() not in cat_lower:
                continue
        if site_names:
            if not any(s.lower() in name.lower() for s in site_names):
                continue
        filtered[name] = info
    return filtered


def generate_username_variations(username: str) -> List[str]:
    """Generate common OSINT variations of a target username."""
    base = username.strip()
    variations = [base]

    # Add common separators/affixes if not already present
    candidates = [
        f"{base}_",
        f"_{base}",
        f"{base}.official",
        f"real_{base}",
        f"{base}1",
        f"the_{base}",
    ]
    if "_" in base:
        candidates.append(base.replace("_", "."))
        candidates.append(base.replace("_", ""))
        candidates.append(base.replace("_", "-"))
    elif "." in base:
        candidates.append(base.replace(".", "_"))
        candidates.append(base.replace(".", ""))
        candidates.append(base.replace(".", "-"))
    elif "-" in base:
        candidates.append(base.replace("-", "_"))
        candidates.append(base.replace("-", ""))

    for cand in candidates:
        if cand not in variations and len(cand) >= 2:
            variations.append(cand)
    return variations
