"""
N-OSINT — Next-Gen Open Source Intelligence Username Scanner.
Search for usernames across 180+ social networks and platforms worldwide.
"""

__version__ = "1.0.0"
__author__ = "Dem1"
