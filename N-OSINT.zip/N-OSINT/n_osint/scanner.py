"""
Asynchronous & multi-threaded OSINT scanner engine for N-OSINT.
Supports httpx (async), aiohttp (async), and standard library urllib (threaded fallback).
"""

import asyncio
import html
import json
import random
import re
import ssl
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
]

# Common anti-bot / WAF markers that might return 200 or 403 and shouldn't be treated as FOUND
WAF_MARKERS = [
    "Just a moment...",
    "cf-browser-verification",
    "Attention Required! | Cloudflare",
    "Access Denied</title>",
    "g-recaptcha",
    "Please verify you are a human",
]


@dataclass
class ScanResult:
    site_name: str
    category: str
    username: str
    url: str
    status: str  # "FOUND", "NOT_FOUND", "SKIPPED", "ERROR", "WAF"
    http_code: int = 0
    elapsed_ms: int = 0
    metadata: str = ""
    error_detail: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "site_name": self.site_name,
            "category": self.category,
            "username": self.username,
            "url": self.url,
            "status": self.status,
            "http_code": self.http_code,
            "elapsed_ms": self.elapsed_ms,
            "metadata": self.metadata,
            "error_detail": self.error_detail,
        }


def extract_page_metadata(body: str, site_name: str) -> str:
    """Extract short profile summary (title / bio / JSON info) from response body."""
    if not body:
        return ""

    # Check if body is JSON (for API probes like GitHub, GitLab, Reddit, Chess.com, etc.)
    stripped = body.strip()
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            data = json.loads(stripped)
            if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
                data = data[0]
            if isinstance(data, dict):
                if "data" in data and isinstance(data["data"], dict):
                    data = data["data"]
                parts = []
                for key in ("name", "display_name", "fullname", "title", "handle", "login"):
                    val = data.get(key)
                    if isinstance(val, str) and val.strip():
                        parts.append(val.strip())
                        break
                for key in ("bio", "description", "about"):
                    val = data.get(key)
                    if isinstance(val, str) and val.strip():
                        clean_bio = " ".join(val.strip().split())[:65]
                        parts.append(clean_bio)
                        break
                for key in ("followers", "public_repos", "total_karma"):
                    val = data.get(key)
                    if isinstance(val, int):
                        parts.append(f"{key}: {val}")
                        break
                if parts:
                    return " | ".join(parts)[:90]
        except Exception:
            pass

    # Extract OpenGraph title or HTML <title>
    og_match = re.search(
        r'<meta\s+(?:property|name)=["\']og:title["\']\s+content=["\']([^"\']+)["\']',
        body,
        re.IGNORECASE,
    )
    if not og_match:
        og_match = re.search(
            r'<meta\s+content=["\']([^"\']+)["\']\s+(?:property|name)=["\']og:title["\']',
            body,
            re.IGNORECASE,
        )
    if og_match:
        title = html.unescape(og_match.group(1)).strip()
        title = " ".join(title.split())
        if title and len(title) > 2:
            return title[:85]

    title_match = re.search(r"<title[^>]*>(.*?)</title>", body, re.IGNORECASE | re.DOTALL)
    if title_match:
        title = html.unescape(title_match.group(1)).strip()
        title = " ".join(title.split())
        if title and not any(w.lower() in title.lower() for w in ("just a moment", "error", "404", "not found")):
            return title[:85]

    return ""


def evaluate_response(
    site_name: str,
    site_info: Dict[str, Any],
    username: str,
    profile_url: str,
    status_code: int,
    body: str,
    final_url: str,
    elapsed_ms: int,
    extract_meta: bool = True,
) -> ScanResult:
    """Evaluate HTTP response against platform-specific detection rules."""
    category = site_info.get("category", "social")
    error_type = site_info.get("error_type", "status_code")
    error_msgs = site_info.get("error_msg", [])
    found_msgs = site_info.get("found_msg", [])

    if isinstance(error_msgs, str):
        error_msgs = [error_msgs]
    if isinstance(found_msgs, str):
        found_msgs = [found_msgs]

    # Check WAF / anti-bot blocks
    if status_code in (403, 429, 503):
        for marker in WAF_MARKERS:
            if marker.lower() in body.lower():
                return ScanResult(
                    site_name=site_name,
                    category=category,
                    username=username,
                    url=profile_url,
                    status="WAF",
                    http_code=status_code,
                    elapsed_ms=elapsed_ms,
                    error_detail="Cloudflare / WAF Challenge",
                )
        return ScanResult(
            site_name=site_name,
            category=category,
            username=username,
            url=profile_url,
            status="NOT_FOUND" if status_code == 404 else "WAF",
            http_code=status_code,
            elapsed_ms=elapsed_ms,
            error_detail=f"HTTP {status_code}",
        )

    if status_code == 404 or status_code >= 400:
        return ScanResult(
            site_name=site_name,
            category=category,
            username=username,
            url=profile_url,
            status="NOT_FOUND",
            http_code=status_code,
            elapsed_ms=elapsed_ms,
        )

    # Check if a 200 page is actually a soft-WAF challenge
    if any(marker.lower() in body[:4000].lower() for marker in WAF_MARKERS):
        return ScanResult(
            site_name=site_name,
            category=category,
            username=username,
            url=profile_url,
            status="WAF",
            http_code=status_code,
            elapsed_ms=elapsed_ms,
            error_detail="Soft WAF / Captcha",
        )

    body_lower = body.lower()

    # Always check negative error_msg if provided
    for msg in error_msgs:
        if msg.lower() in body_lower:
            return ScanResult(
                site_name=site_name,
                category=category,
                username=username,
                url=profile_url,
                status="NOT_FOUND",
                http_code=status_code,
                elapsed_ms=elapsed_ms,
            )

    # Check redirect error type
    if error_type == "response_url":
        for msg in error_msgs:
            if msg.lower() in final_url.lower():
                return ScanResult(
                    site_name=site_name,
                    category=category,
                    username=username,
                    url=profile_url,
                    status="NOT_FOUND",
                    http_code=status_code,
                    elapsed_ms=elapsed_ms,
                )
        # Also if redirected to generic login/home page without username
        if username.lower() not in final_url.lower():
            return ScanResult(
                site_name=site_name,
                category=category,
                username=username,
                url=profile_url,
                status="NOT_FOUND",
                http_code=status_code,
                elapsed_ms=elapsed_ms,
            )

    # If positive `found_msg` markers are configured, at least one must match
    if found_msgs:
        if not any(f_msg.lower() in body_lower for f_msg in found_msgs):
            return ScanResult(
                site_name=site_name,
                category=category,
                username=username,
                url=profile_url,
                status="NOT_FOUND",
                http_code=status_code,
                elapsed_ms=elapsed_ms,
            )

    if 200 <= status_code < 300:
        meta = extract_page_metadata(body, site_name) if extract_meta else ""
        return ScanResult(
            site_name=site_name,
            category=category,
            username=username,
            url=profile_url,
            status="FOUND",
            http_code=status_code,
            elapsed_ms=elapsed_ms,
            metadata=meta,
        )

    return ScanResult(
        site_name=site_name,
        category=category,
        username=username,
        url=profile_url,
        status="NOT_FOUND",
        http_code=status_code,
        elapsed_ms=elapsed_ms,
    )


class NOSINTScanner:
    """High-speed OSINT username scanner across global platforms."""

    def __init__(
        self,
        timeout: float = 10.0,
        concurrency: int = 40,
        proxy: Optional[str] = None,
        extract_metadata: bool = True,
        verify_ssl: bool = True,
    ):
        self.timeout = timeout
        self.concurrency = max(1, min(concurrency, 150))
        self.proxy = proxy
        self.extract_metadata = extract_metadata
        self.verify_ssl = verify_ssl

    def _build_headers(self, custom_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7",
            "Accept-Language": "en-US,en;q=0.9,ru;q=0.8",
        }
        if custom_headers:
            headers.update(custom_headers)
        return headers

    def _validate_regex(
        self, site_name: str, site_info: Dict[str, Any], username: str
    ) -> Optional[ScanResult]:
        regex = site_info.get("regex_check")
        if regex and not re.match(regex, username):
            return ScanResult(
                site_name=site_name,
                category=site_info.get("category", "social"),
                username=username,
                url=site_info["url"].format(username),
                status="SKIPPED",
                error_detail="Invalid username format for platform",
            )
        return None

    async def _probe_httpx(
        self,
        client: "httpx.AsyncClient",
        semaphore: asyncio.Semaphore,
        site_name: str,
        site_info: Dict[str, Any],
        username: str,
        on_result: Optional[Callable[[ScanResult], None]] = None,
    ) -> ScanResult:
        skipped = self._validate_regex(site_name, site_info, username)
        if skipped:
            if on_result:
                on_result(skipped)
            return skipped

        profile_url = site_info["url"].format(username)
        probe_url = site_info.get("url_probe", site_info["url"]).format(username)
        headers = self._build_headers(site_info.get("headers"))

        async with semaphore:
            start = time.perf_counter()
            try:
                resp = await client.get(probe_url, headers=headers, follow_redirects=True)
                elapsed_ms = int((time.perf_counter() - start) * 1000)
                body = resp.text[:50000] if resp.text else ""
                result = evaluate_response(
                    site_name=site_name,
                    site_info=site_info,
                    username=username,
                    profile_url=profile_url,
                    status_code=resp.status_code,
                    body=body,
                    final_url=str(resp.url),
                    elapsed_ms=elapsed_ms,
                    extract_meta=self.extract_metadata,
                )
            except Exception as exc:
                elapsed_ms = int((time.perf_counter() - start) * 1000)
                result = ScanResult(
                    site_name=site_name,
                    category=site_info.get("category", "social"),
                    username=username,
                    url=profile_url,
                    status="ERROR",
                    elapsed_ms=elapsed_ms,
                    error_detail=type(exc).__name__,
                )

            if on_result:
                on_result(result)
            return result

    async def _probe_aiohttp(
        self,
        session: "aiohttp.ClientSession",
        semaphore: asyncio.Semaphore,
        site_name: str,
        site_info: Dict[str, Any],
        username: str,
        on_result: Optional[Callable[[ScanResult], None]] = None,
    ) -> ScanResult:
        skipped = self._validate_regex(site_name, site_info, username)
        if skipped:
            if on_result:
                on_result(skipped)
            return skipped

        profile_url = site_info["url"].format(username)
        probe_url = site_info.get("url_probe", site_info["url"]).format(username)
        headers = self._build_headers(site_info.get("headers"))

        async with semaphore:
            start = time.perf_counter()
            try:
                async with session.get(
                    probe_url,
                    headers=headers,
                    allow_redirects=True,
                    proxy=self.proxy,
                    ssl=self.verify_ssl,
                ) as resp:
                    raw = await resp.read()
                    body = raw[:50000].decode("utf-8", errors="ignore")
                    elapsed_ms = int((time.perf_counter() - start) * 1000)
                    result = evaluate_response(
                        site_name=site_name,
                        site_info=site_info,
                        username=username,
                        profile_url=profile_url,
                        status_code=resp.status,
                        body=body,
                        final_url=str(resp.url),
                        elapsed_ms=elapsed_ms,
                        extract_meta=self.extract_metadata,
                    )
            except Exception as exc:
                elapsed_ms = int((time.perf_counter() - start) * 1000)
                result = ScanResult(
                    site_name=site_name,
                    category=site_info.get("category", "social"),
                    username=username,
                    url=profile_url,
                    status="ERROR",
                    elapsed_ms=elapsed_ms,
                    error_detail=type(exc).__name__,
                )

            if on_result:
                on_result(result)
            return result

    def _probe_urllib_sync(
        self,
        site_name: str,
        site_info: Dict[str, Any],
        username: str,
        on_result: Optional[Callable[[ScanResult], None]] = None,
    ) -> ScanResult:
        skipped = self._validate_regex(site_name, site_info, username)
        if skipped:
            if on_result:
                on_result(skipped)
            return skipped

        profile_url = site_info["url"].format(username)
        probe_url = site_info.get("url_probe", site_info["url"]).format(username)
        headers = self._build_headers(site_info.get("headers"))

        start = time.perf_counter()
        ctx = ssl.create_default_context()
        if not self.verify_ssl:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

        req = urllib.request.Request(probe_url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=ctx) as resp:
                status_code = resp.getcode() or 200
                final_url = resp.geturl() or probe_url
                raw = resp.read(50000)
                body = raw.decode("utf-8", errors="ignore")
                elapsed_ms = int((time.perf_counter() - start) * 1000)
                result = evaluate_response(
                    site_name=site_name,
                    site_info=site_info,
                    username=username,
                    profile_url=profile_url,
                    status_code=status_code,
                    body=body,
                    final_url=final_url,
                    elapsed_ms=elapsed_ms,
                    extract_meta=self.extract_metadata,
                )
        except urllib.error.HTTPError as http_err:
            elapsed_ms = int((time.perf_counter() - start) * 1000)
            try:
                body = http_err.read(20000).decode("utf-8", errors="ignore")
            except Exception:
                body = ""
            result = evaluate_response(
                site_name=site_name,
                site_info=site_info,
                username=username,
                profile_url=profile_url,
                status_code=http_err.code,
                body=body,
                final_url=probe_url,
                elapsed_ms=elapsed_ms,
                extract_meta=self.extract_metadata,
            )
        except Exception as exc:
            elapsed_ms = int((time.perf_counter() - start) * 1000)
            result = ScanResult(
                site_name=site_name,
                category=site_info.get("category", "social"),
                username=username,
                url=profile_url,
                status="ERROR",
                elapsed_ms=elapsed_ms,
                error_detail=type(exc).__name__,
            )

        if on_result:
            on_result(result)
        return result

    async def scan_username_async(
        self,
        username: str,
        sites: Dict[str, Dict[str, Any]],
        on_result: Optional[Callable[[ScanResult], None]] = None,
    ) -> List[ScanResult]:
        """Run asynchronous scan for a single username across given sites."""
        semaphore = asyncio.Semaphore(self.concurrency)

        if HAS_HTTPX:
            limits = httpx.Limits(
                max_keepalive_connections=self.concurrency,
                max_connections=self.concurrency + 10,
            )
            client_kwargs: Dict[str, Any] = {
                "timeout": httpx.Timeout(self.timeout),
                "limits": limits,
                "verify": self.verify_ssl,
            }
            if self.proxy:
                client_kwargs["proxy"] = self.proxy

            async with httpx.AsyncClient(**client_kwargs) as client:
                tasks = [
                    self._probe_httpx(client, semaphore, name, info, username, on_result)
                    for name, info in sites.items()
                ]
                return await asyncio.gather(*tasks)

        if HAS_AIOHTTP:
            timeout_cfg = aiohttp.ClientTimeout(total=self.timeout)
            connector = aiohttp.TCPConnector(limit=self.concurrency, ssl=self.verify_ssl)
            async with aiohttp.ClientSession(timeout=timeout_cfg, connector=connector) as session:
                tasks = [
                    self._probe_aiohttp(session, semaphore, name, info, username, on_result)
                    for name, info in sites.items()
                ]
                return await asyncio.gather(*tasks)

        # Fallback: standard library urllib with ThreadPoolExecutor
        loop = asyncio.get_running_loop()
        with ThreadPoolExecutor(max_workers=min(self.concurrency, 32)) as pool:
            tasks = [
                loop.run_in_executor(
                    pool, self._probe_urllib_sync, name, info, username, on_result
                )
                for name, info in sites.items()
            ]
            return list(await asyncio.gather(*tasks))

    def scan_username(
        self,
        username: str,
        sites: Dict[str, Dict[str, Any]],
        on_result: Optional[Callable[[ScanResult], None]] = None,
    ) -> List[ScanResult]:
        """Synchronous wrapper around scan_username_async."""
        return asyncio.run(self.scan_username_async(username, sites, on_result))
