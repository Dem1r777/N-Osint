"""
Export N-OSINT scan results to TXT, JSON, CSV, or standalone dark-themed HTML report.
"""

import csv
import html
import json
from datetime import datetime
from pathlib import Path
from typing import List

from .i18n import get_category_label
from .scanner import ScanResult


def export_txt(results: List[ScanResult], filepath: Path, username: str) -> Path:
    found = [r for r in results if r.status == "FOUND"]
    lines = [
        "=" * 72,
        f" N-OSINT (Created by Dem1) — USERNAME RECON REPORT: @{username}",
        f" Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f" Found profiles: {len(found)} / {len(results)} platforms checked",
        "=" * 72,
        "",
    ]
    for res in sorted(found, key=lambda x: (x.category, x.site_name)):
        meta_str = f"  [{res.metadata}]" if res.metadata else ""
        lines.append(f"[+] {res.site_name:<28} -> {res.url} ({res.elapsed_ms} ms){meta_str}")

    lines.append("")
    lines.append("=" * 72)
    filepath.write_text("\n".join(lines), encoding="utf-8")
    return filepath


def export_json(results: List[ScanResult], filepath: Path, username: str) -> Path:
    found = [r for r in results if r.status == "FOUND"]
    payload = {
        "tool": "N-OSINT",
        "target_username": username,
        "timestamp": datetime.now().isoformat(),
        "summary": {
            "total_checked": len(results),
            "found_count": len(found),
            "not_found_count": sum(1 for r in results if r.status == "NOT_FOUND"),
            "waf_or_blocked": sum(1 for r in results if r.status == "WAF"),
            "errors": sum(1 for r in results if r.status == "ERROR"),
            "skipped": sum(1 for r in results if r.status == "SKIPPED"),
        },
        "found_profiles": [r.to_dict() for r in found],
        "all_results": [r.to_dict() for r in results],
    }
    filepath.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return filepath


def export_csv(results: List[ScanResult], filepath: Path, only_found: bool = True) -> Path:
    rows = [r for r in results if (r.status == "FOUND" if only_found else True)]
    with filepath.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(
            ["Username", "Platform", "Category", "Status", "URL", "HTTP_Code", "Latency_ms", "Metadata"]
        )
        for r in rows:
            writer.writerow(
                [
                    r.username,
                    r.site_name,
                    get_category_label(r.category),
                    r.status,
                    r.url,
                    r.http_code,
                    r.elapsed_ms,
                    r.metadata,
                ]
            )
    return filepath


def export_html(results: List[ScanResult], filepath: Path, username: str) -> Path:
    found = [r for r in results if r.status == "FOUND"]
    cards_html = []
    for r in sorted(found, key=lambda x: (x.category, x.site_name)):
        cat_label = html.escape(get_category_label(r.category))
        site = html.escape(r.site_name)
        url = html.escape(r.url)
        meta = html.escape(r.metadata) if r.metadata else "Public profile detected"
        cards_html.append(
            f"""
            <div class="card" data-category="{html.escape(r.category)}">
                <div class="card-header">
                    <span class="site-name">{site}</span>
                    <span class="badge">{r.elapsed_ms} ms</span>
                </div>
                <div class="category">{cat_label}</div>
                <div class="meta">{meta}</div>
                <a class="profile-link" href="{url}" target="_blank" rel="noopener noreferrer">{url} ↗</a>
            </div>
            """
        )

    doc = f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>N-OSINT Report — @{html.escape(username)}</title>
<style>
  :root {{
    --bg: #0b0f19;
    --card: #131b2e;
    --border: #1e293b;
    --accent: #00f0ff;
    --accent2: #10b981;
    --text: #e2e8f0;
    --muted: #94a3b8;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: var(--bg);
    color: var(--text);
    padding: 2rem;
  }}
  .header {{
    max-width: 1200px;
    margin: 0 auto 2rem auto;
    border-bottom: 1px solid var(--border);
    padding-bottom: 1.5rem;
  }}
  .title {{
    font-size: 2rem;
    font-weight: 800;
    color: var(--accent);
    letter-spacing: 1px;
  }}
  .subtitle {{ color: var(--muted); margin-top: 0.5rem; }}
  .stats {{
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
    flex-wrap: wrap;
  }}
  .stat-box {{
    background: var(--card);
    border: 1px solid var(--border);
    padding: 0.75rem 1.25rem;
    border-radius: 8px;
  }}
  .stat-val {{ font-size: 1.4rem; font-weight: 700; color: var(--accent2); }}
  .grid {{
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 1rem;
  }}
  .card {{
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 1.1rem;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    transition: transform 0.15s ease, border-color 0.15s ease;
  }}
  .card:hover {{
    transform: translateY(-2px);
    border-color: var(--accent);
  }}
  .card-header {{
    display: flex;
    justify-content: space-between;
    align-items: center;
  }}
  .site-name {{ font-weight: 700; font-size: 1.1rem; color: #fff; }}
  .badge {{
    background: rgba(16, 185, 129, 0.15);
    color: var(--accent2);
    padding: 2px 8px;
    border-radius: 99px;
    font-size: 0.78rem;
  }}
  .category {{ font-size: 0.8rem; color: var(--accent); }}
  .meta {{ font-size: 0.88rem; color: var(--muted); flex-grow: 1; }}
  .profile-link {{
    color: #38bdf8;
    text-decoration: none;
    font-size: 0.85rem;
    word-break: break-all;
    margin-top: 0.4rem;
  }}
  .profile-link:hover {{ text-decoration: underline; }}
</style>
</head>
<body>
  <div class="header">
    <div class="title">N-OSINT // RECON REPORT</div>
    <div class="subtitle">Created by Dem1 &bull; Target: <strong>@{html.escape(username)}</strong> &bull; {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
    <div class="stats">
      <div class="stat-box"><div class="stat-val">{len(found)}</div><div>Found Profiles</div></div>
      <div class="stat-box"><div class="stat-val">{len(results)}</div><div>Platforms Checked</div></div>
    </div>
  </div>
  <div class="grid">
    {''.join(cards_html)}
  </div>
</body>
</html>
"""
    filepath.write_text(doc, encoding="utf-8")
    return filepath
