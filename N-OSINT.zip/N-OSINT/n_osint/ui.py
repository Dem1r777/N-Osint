"""
Terminal User Interface (TUI) and Rich output rendering for N-OSINT.
Includes interactive menu, language switcher (English / Russian / Tajik),
ASCII banner, live progress bar, and categorized tables.
"""

import asyncio
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from .exporter import export_csv, export_html, export_json, export_txt
from .i18n import LANGUAGE_NAMES, get_category_label, get_lang, set_lang, t
from .scanner import NOSINTScanner, ScanResult
from .sites import CATEGORIES, SITES_DB, generate_username_variations, get_sites

try:
    from rich import box
    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import (
        BarColumn,
        MofNCompleteColumn,
        Progress,
        SpinnerColumn,
        TaskProgressColumn,
        TextColumn,
        TimeElapsedColumn,
    )
    from rich.prompt import Confirm, Prompt
    from rich.table import Table
    from rich.text import Text

    HAS_RICH = True
    console = Console()
except ImportError:
    HAS_RICH = False
    console = None


BANNER_ASCII = r"""
  _   _         ____   _____ _____ _   _ _______ 
 | \ | |       / __ \ / ____|_   _| \ | |__   __|
 |  \| |______| |  | | (___   | | |  \| |  | |   
 | . ` |______| |  | |\___ \  | | | . ` |  | |   
 | |\  |      | |__| |____) |_| |_| |\  |  | |   
 |_| \_|       \____/|_____/|_____|_| \_|  |_|   
"""


def enable_windows_ansi() -> None:
    """Enable ANSI escape codes in Windows terminal if needed."""
    if os.name == "nt":
        os.system("")


def print_banner() -> None:
    enable_windows_ansi()
    total_sites = len(SITES_DB)
    total_cats = len(CATEGORIES)

    if HAS_RICH:
        banner_text = Text(BANNER_ASCII.rstrip("\n"), style="bold cyan")
        banner_text.append("\n                  Created by Dem1\n", style="dim italic bright_white")
        subtitle = (
            f"[bold white]{t('banner_subtitle')}[/bold white]\n"
            f"[dim]{t('banner_platforms')}[/dim] [bold green]{total_sites}[/bold green]  "
            f"[dim]|  {t('banner_categories')}[/dim] [bold yellow]{total_cats}[/bold yellow]  "
            f"[dim]|  Created by Dem1[/dim]"
        )
        console.print(
            Panel(
                banner_text,
                subtitle=subtitle,
                border_style="bright_cyan",
                box=box.DOUBLE_EDGE,
                padding=(0, 2),
            )
        )
    else:
        print("\033[96m" + BANNER_ASCII.rstrip("\n") + "\033[0m")
        print("\033[2m                  Created by Dem1\033[0m\n")
        print(
            f"  {t('banner_subtitle')} | {t('banner_platforms')} {total_sites} | "
            f"{t('banner_categories')} {total_cats}"
        )
        print("=" * 74)


def display_categories_table() -> List[str]:
    """Render numbered table of all platform categories and return category keys."""
    cat_keys = list(CATEGORIES.keys())
    if HAS_RICH:
        table = Table(
            title=t("cat_table_title"),
            box=box.ROUNDED,
            border_style="cyan",
            header_style="bold bright_cyan",
        )
        table.add_column("№", justify="right", style="bold yellow", width=4)
        table.add_column(t("cat_col_code"), style="cyan", width=14)
        table.add_column(t("cat_col_desc"), style="white")
        table.add_column(t("cat_col_sites"), justify="right", style="bold green", width=8)

        for idx, key in enumerate(cat_keys, 1):
            count = sum(1 for s in SITES_DB.values() if s.get("category") == key)
            table.add_row(str(idx), key, get_category_label(key), str(count))
        table.add_row("0", "back", f"[dim]{t('back_label')}[/dim]", "—")
        console.print(table)
    else:
        print(f"\n{t('cat_table_title')}:")
        for idx, key in enumerate(cat_keys, 1):
            count = sum(1 for s in SITES_DB.values() if s.get("category") == key)
            print(f"  [{idx}] {key:<14} - {get_category_label(key)} ({count})")
        print(f"  [0] back           - {t('back_label')}")
    return cat_keys


def display_sites_catalog(category_filter: Optional[str] = None) -> None:
    """Display full catalog of supported platforms."""
    sites = get_sites(categories=[category_filter] if category_filter else None)
    if HAS_RICH:
        table = Table(
            title=t("catalog_title", count=len(sites)),
            box=box.SIMPLE_HEAVY,
            border_style="bright_blue",
            header_style="bold cyan",
        )
        table.add_column("№", justify="right", style="dim", width=4)
        table.add_column(t("catalog_col_platform"), style="bold white", width=28)
        table.add_column(t("catalog_col_category"), style="cyan", width=34)
        table.add_column(t("catalog_col_url"), style="bright_blue")

        for idx, (name, info) in enumerate(sorted(sites.items(), key=lambda x: (x[1]["category"], x[0])), 1):
            cat_name = get_category_label(info["category"])
            table.add_row(str(idx), name, cat_name, info["url"].format("<username>"))
        console.print(table)
    else:
        for idx, (name, info) in enumerate(sorted(sites.items()), 1):
            print(f"{idx:3d}. {name:<28} [{get_category_label(info['category'])}] -> {info['url'].format('<username>')}")


def run_scan_with_progress(
    scanner: NOSINTScanner,
    username: str,
    sites: Dict[str, Dict[str, Any]],
    verbose: bool = False,
) -> List[ScanResult]:
    """Execute scan for a username while displaying live progress bar and real-time hits."""
    results: List[ScanResult] = []
    found_count = 0
    start_time = time.perf_counter()

    if HAS_RICH:
        console.print(
            f"\n[bold cyan][*][/bold cyan] "
            + t(
                "scan_header",
                username=username,
                count=len(sites),
                concurrency=scanner.concurrency,
                timeout=scanner.timeout,
            )
            + "\n"
        )

        progress = Progress(
            SpinnerColumn(style="bright_cyan"),
            TextColumn("[bold cyan]{task.description}"),
            BarColumn(bar_width=36, complete_style="bright_cyan", finished_style="bright_green"),
            MofNCompleteColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            console=console,
            transient=False,
        )

        with progress:
            task_id = progress.add_task(t("scan_task", username=username), total=len(sites))

            def on_result(res: ScanResult) -> None:
                nonlocal found_count
                results.append(res)
                if res.status == "FOUND":
                    found_count += 1
                    meta_badge = f" [dim italic]({res.metadata})[/dim italic]" if res.metadata else ""
                    progress.console.print(
                        f"  [bold bright_green][+][/bold bright_green] "
                        f"[bold white]{res.site_name:<26}[/bold white] "
                        f"[underline bright_cyan]{res.url}[/underline bright_cyan] "
                        f"[dim]{res.elapsed_ms}ms[/dim]{meta_badge}"
                    )
                elif verbose:
                    if res.status == "NOT_FOUND":
                        progress.console.print(
                            f"  [dim][-] {res.site_name:<26} {t('not_found_live', ms=res.elapsed_ms)}[/dim]"
                        )
                    elif res.status == "WAF":
                        progress.console.print(
                            f"  [yellow][!] {res.site_name:<26} {t('waf_live', detail=res.error_detail)}[/yellow]"
                        )
                    elif res.status == "ERROR":
                        progress.console.print(
                            f"  [red][x] {res.site_name:<26} {t('err_live', detail=res.error_detail)}[/red]"
                        )

                progress.update(
                    task_id,
                    advance=1,
                    description=t("scan_task_found", username=username, found=found_count),
                )

            asyncio.run(scanner.scan_username_async(username, sites, on_result=on_result))

    else:
        print(f"\n[*] {t('scan_task', username=username)} ({len(sites)})...")
        completed = 0

        def on_result_plain(res: ScanResult) -> None:
            nonlocal found_count, completed
            completed += 1
            results.append(res)
            if res.status == "FOUND":
                found_count += 1
                meta_str = f" ({res.metadata})" if res.metadata else ""
                print(f"  \033[92m[+]\033[0m {res.site_name:<26} -> {res.url} [{res.elapsed_ms}ms]{meta_str}")
            elif verbose and res.status != "NOT_FOUND":
                print(f"  [!] {res.site_name:<26} -> {res.status} ({res.error_detail})")

        asyncio.run(scanner.scan_username_async(username, sites, on_result=on_result_plain))

    total_sec = time.perf_counter() - start_time
    render_summary(results, username, total_sec)
    return results


def render_summary(results: List[ScanResult], username: str, elapsed_sec: float) -> None:
    """Render categorized summary table and statistics after scan completion."""
    found = [r for r in results if r.status == "FOUND"]
    not_found = sum(1 for r in results if r.status == "NOT_FOUND")
    waf = sum(1 for r in results if r.status == "WAF")
    errors = sum(1 for r in results if r.status == "ERROR")
    skipped = sum(1 for r in results if r.status == "SKIPPED")

    if HAS_RICH:
        console.print()
        if found:
            table = Table(
                title=t("found_table_title", username=username, count=len(found)),
                box=box.ROUNDED,
                border_style="bright_green",
                header_style="bold bright_green",
                show_lines=False,
            )
            table.add_column("№", justify="right", style="dim", width=4)
            table.add_column(t("col_platform"), style="bold white", width=26)
            table.add_column(t("col_category"), style="cyan", width=28)
            table.add_column(t("col_url"), style="underline bright_cyan")
            table.add_column(t("col_info"), style="dim white", max_width=36)
            table.add_column(t("col_ping"), justify="right", style="green", width=8)

            for idx, r in enumerate(sorted(found, key=lambda x: (x.category, x.site_name)), 1):
                cat_title = get_category_label(r.category).split("(")[0].strip()
                table.add_row(
                    str(idx),
                    r.site_name,
                    cat_title,
                    r.url,
                    r.metadata or "—",
                    f"{r.elapsed_ms} ms",
                )
            console.print(table)
        else:
            console.print(
                Panel(
                    f"[yellow]{t('none_found', username=username)}[/yellow]",
                    border_style="yellow",
                )
            )

        stats_text = (
            f"[bold green]✔ {t('stat_found')}[/bold green] {len(found)}   "
            f"[dim]✖ {t('stat_not_found')}[/dim] {not_found}   "
            f"[yellow]⚡ {t('stat_waf')}[/yellow] {waf}   "
            f"[red]⚠ {t('stat_err')}[/red] {errors}   "
            f"[dim]⏭ {t('stat_skipped')}[/dim] {skipped}   "
            f"[bold cyan]⏱ {t('stat_time')}[/bold cyan] {elapsed_sec:.2f} {t('stat_sec')}"
        )
        console.print(Panel(stats_text, title=t("stats_title"), border_style="cyan"))
    else:
        print("\n" + "=" * 74)
        print(
            f"@{username}: {t('stat_found')} {len(found)} | {t('stat_not_found')} {not_found} | "
            f"{t('stat_waf')} {waf} | {t('stat_err')} {errors} | {t('stat_time')} {elapsed_sec:.2f} {t('stat_sec')}"
        )
        print("=" * 74)


def prompt_save_reports(results: List[ScanResult], username: str) -> None:
    """Ask user in interactive mode whether to export reports."""
    found = [r for r in results if r.status == "FOUND"]
    if not found:
        return

    reports_dir = Path("reports")
    if HAS_RICH:
        save = Confirm.ask(
            f"\n[bold cyan]{t('ask_save_reports')}[/bold cyan]",
            default=True,
        )
    else:
        ans = input(f"\n{t('ask_save_reports')} [Y/n]: ").strip().lower()
        save = ans in ("", "y", "yes", "д", "да", "ҳ", "ҳа")

    if not save:
        return

    reports_dir.mkdir(parents=True, exist_ok=True)
    safe_user = "".join(c if c.isalnum() or c in "._-" else "_" for c in username)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    base_name = f"{safe_user}_{timestamp}"

    txt_path = export_txt(results, reports_dir / f"{base_name}.txt", username)
    json_path = export_json(results, reports_dir / f"{base_name}.json", username)
    html_path = export_html(results, reports_dir / f"{base_name}.html", username)
    csv_path = export_csv(results, reports_dir / f"{base_name}.csv")

    if HAS_RICH:
        console.print(
            Panel(
                f"[green]✔ {t('report_txt')}[/green]  {txt_path.resolve()}\n"
                f"[green]✔ {t('report_html')}[/green] {html_path.resolve()}\n"
                f"[green]✔ {t('report_json')}[/green] {json_path.resolve()}\n"
                f"[green]✔ {t('report_csv')}[/green] {csv_path.resolve()}",
                title=t("reports_saved_title"),
                border_style="bright_green",
            )
        )
    else:
        print(f"[+] {t('reports_saved_title')}: {reports_dir.resolve()}")


def prompt_language_switch() -> bool:
    """Interactive language selection menu (English, Russian, Tajik). Returns True if changed."""
    if HAS_RICH:
        lang_table = Table.grid(padding=(0, 2))
        lang_table.add_column(style="bold yellow", justify="right")
        lang_table.add_column(style="bold white")
        lang_table.add_row("[1]", "English (Default)")
        lang_table.add_row("[2]", "Русский (Russian)")
        lang_table.add_row("[3]", "Тоҷикӣ (Tajik)")
        lang_table.add_row("[0]", f"[dim]{t('back_label')}[/dim]")

        console.print()
        console.print(
            Panel(
                lang_table,
                title=f"[bold bright_cyan]{t('lang_menu_title')}[/bold bright_cyan]",
                border_style="cyan",
                box=box.ROUNDED,
            )
        )
        sel = Prompt.ask("[bold cyan]>[/bold cyan]", choices=["1", "2", "3", "0"], default="0")
    else:
        print(f"\n--- {t('lang_menu_title')} ---")
        print("[1] English (Default)")
        print("[2] Русский (Russian)")
        print("[3] Тоҷикӣ (Tajik)")
        print(f"[0] {t('back_label')}")
        sel = input("> [0]: ").strip() or "0"

    if sel == "0":
        return False

    mapping = {"1": "en", "2": "ru", "3": "tg"}
    set_lang(mapping.get(sel, "en"))
    if HAS_RICH:
        console.print(f"[bold green]✔ {t('lang_changed')}[/bold green]")
    else:
        print(f"[+] {t('lang_changed')}")
    return True


def run_interactive_tui() -> None:
    """Interactive Terminal UI loop when N-OSINT is launched without CLI flags."""
    print_banner()

    timeout = 10.0
    concurrency = 45
    proxy: Optional[str] = None
    verbose = False

    while True:
        cur_lang_name = LANGUAGE_NAMES.get(get_lang(), "English")
        proxy_label = proxy or t("none_val")

        if HAS_RICH:
            menu = Table.grid(padding=(0, 2))
            menu.add_column(style="bold yellow", justify="right")
            menu.add_column(style="white")
            menu.add_row("[1]", t("menu_1"))
            menu.add_row("[2]", t("menu_2"))
            menu.add_row("[3]", t("menu_3"))
            menu.add_row("[4]", t("menu_4"))
            menu.add_row("[5]", t("menu_5", count=len(SITES_DB)))
            menu.add_row(
                "[6]",
                t("menu_6", concurrency=concurrency, timeout=timeout, proxy=proxy_label),
            )
            menu.add_row("[7]", t("menu_7", lang=cur_lang_name))
            menu.add_row("[0]", t("menu_0"))

            console.print()
            console.print(
                Panel(
                    menu,
                    title=f"[bold bright_cyan]{t('menu_title')}[/bold bright_cyan]",
                    border_style="cyan",
                    box=box.ROUNDED,
                )
            )
            choice = Prompt.ask(
                f"[bold cyan]{t('select_action')}[/bold cyan]",
                choices=["1", "2", "3", "4", "5", "6", "7", "0"],
                default="1",
            )
        else:
            print(f"\n--- {t('menu_title')} ---")
            print(f"[1] {t('menu_1')}")
            print(f"[2] {t('menu_2')}")
            print(f"[3] {t('menu_3')}")
            print(f"[4] {t('menu_4')}")
            print(f"[5] {t('menu_5', count=len(SITES_DB))}")
            print(f"[6] {t('menu_6', concurrency=concurrency, timeout=timeout, proxy=proxy_label)}")
            print(f"[7] {t('menu_7', lang=cur_lang_name)}")
            print(f"[0] {t('menu_0')}")
            choice = input(f"{t('select_action')} [1]: ").strip() or "1"

        if choice == "0":
            if HAS_RICH:
                console.print(f"[bold cyan]{t('exit_msg')}[/bold cyan]")
            else:
                print(t("exit_msg"))
            break

        elif choice == "1":
            raw_u = _ask_input(t("ask_usernames"))
            if raw_u is None or not raw_u.strip():
                continue
            usernames = [u.strip().lstrip("@") for u in raw_u.split(",") if u.strip()]
            scanner = NOSINTScanner(timeout=timeout, concurrency=concurrency, proxy=proxy)
            for u in usernames:
                res = run_scan_with_progress(scanner, u, SITES_DB, verbose=verbose)
                prompt_save_reports(res, u)

        elif choice == "2":
            while True:
                cat_keys = display_categories_table()
                raw_sel = _ask_input(t("ask_categories"))
                if raw_sel is None or not raw_sel.strip():
                    break

                selected_cats: List[str] = []
                back_requested = False
                for token in raw_sel.split(","):
                    tok = token.strip().lower()
                    if tok in ("0", "back"):
                        back_requested = True
                        break
                    if tok.isdigit():
                        idx = int(tok) - 1
                        if 0 <= idx < len(cat_keys):
                            selected_cats.append(cat_keys[idx])
                    elif tok in CATEGORIES:
                        selected_cats.append(tok)

                if back_requested:
                    break

                if not selected_cats:
                    selected_cats = ["social", "messengers"]

                sites = get_sites(categories=selected_cats)
                raw_user = _ask_input(t("ask_target_username"))
                if raw_user is None or not raw_user.strip():
                    # Pressing 0 on username prompt returns to category selection
                    continue
                username = raw_user.strip().lstrip("@")
                scanner = NOSINTScanner(timeout=timeout, concurrency=concurrency, proxy=proxy)
                res = run_scan_with_progress(scanner, username, sites, verbose=verbose)
                prompt_save_reports(res, username)
                break

        elif choice == "3":
            while True:
                raw_user = _ask_input(t("ask_base_username"))
                if raw_user is None or not raw_user.strip():
                    break
                username = raw_user.strip().lstrip("@")
                variations = generate_username_variations(username)
                if HAS_RICH:
                    console.print(
                        f"[cyan]{t('generated_variations', count=len(variations))}[/cyan] "
                        + ", ".join(f"[bold yellow]@{v}[/bold yellow]" for v in variations)
                    )
                else:
                    print(t("generated_variations", count=len(variations)), ", ".join(variations))

                only_social = _ask_input(t("ask_only_social"))
                if only_social is None:
                    # Pressing 0 returns to base username input
                    continue
                sites = (
                    get_sites(categories=["social", "messengers", "gaming", "cis"])
                    if only_social.strip().lower() in ("", "y", "yes", "д", "да", "ҳ", "ҳа")
                    else SITES_DB
                )
                scanner = NOSINTScanner(timeout=timeout, concurrency=concurrency, proxy=proxy)
                all_results: List[ScanResult] = []
                for var_nick in variations:
                    res = run_scan_with_progress(scanner, var_nick, sites, verbose=verbose)
                    all_results.extend(res)
                prompt_save_reports(all_results, username)
                break

        elif choice == "4":
            while True:
                site_query = _ask_input(t("ask_site_names"))
                if site_query is None or not site_query.strip():
                    break
                filters = [s.strip() for s in site_query.split(",") if s.strip()]
                sites = get_sites(site_names=filters)
                if not sites:
                    if HAS_RICH:
                        console.print(f"[red]{t('no_sites_matched')}[/red]")
                    else:
                        print(t("no_sites_matched"))
                    continue
                raw_user = _ask_input(t("ask_target_username"))
                if raw_user is None or not raw_user.strip():
                    # Pressing 0 returns to platform filter input
                    continue
                username = raw_user.strip().lstrip("@")
                scanner = NOSINTScanner(timeout=timeout, concurrency=concurrency, proxy=proxy)
                res = run_scan_with_progress(scanner, username, sites, verbose=verbose)
                prompt_save_reports(res, username)
                break

        elif choice == "5":
            display_sites_catalog()
            _ask_input(t("press_0_back"), show_back_hint=False)

        elif choice == "6":
            raw_conc = _ask_input(t("ask_concurrency", val=concurrency))
            if raw_conc is None:
                continue
            if raw_conc.strip().isdigit():
                concurrency = max(1, min(150, int(raw_conc.strip())))

            raw_time = _ask_input(t("ask_timeout", val=timeout))
            if raw_time is None:
                continue
            try:
                if raw_time.strip():
                    timeout = max(2.0, float(raw_time.strip()))
            except ValueError:
                pass

            raw_proxy = _ask_input(t("ask_proxy", val=proxy_label))
            if raw_proxy is None:
                continue
            if raw_proxy.strip():
                proxy = (
                    None
                    if raw_proxy.strip().lower() in ("none", "нет", "нест", "-")
                    else raw_proxy.strip()
                )

            raw_verb = _ask_input(t("ask_verbose", val="y" if verbose else "n"))
            if raw_verb is None:
                continue
            if raw_verb.strip():
                verbose = raw_verb.strip().lower() in ("y", "yes", "д", "да", "ҳ", "ҳа")

        elif choice == "7":
            if prompt_language_switch():
                print_banner()


def _ask_input(prompt_text: str, show_back_hint: bool = True) -> Optional[str]:
    """Prompt user for input; returns None if user enters '0' to go back."""
    if HAS_RICH:
        hint = f" {t('back_hint')}" if show_back_hint else ""
        val = Prompt.ask(f"[bold bright_cyan]>[/bold bright_cyan] {prompt_text}{hint}")
    else:
        hint = f" {t('back_hint_plain')}" if show_back_hint else ""
        val = input(f"> {prompt_text}{hint}: ")

    if val.strip() == "0":
        return None
    return val
