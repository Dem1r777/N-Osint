"""
Command-Line Interface (CLI) parser and entry point for N-OSINT.
"""

import argparse
import sys
import time
from pathlib import Path
from typing import List

from . import __version__
from .exporter import export_csv, export_html, export_json, export_txt
from .i18n import set_lang, t
from .scanner import NOSINTScanner, ScanResult
from .sites import CATEGORIES, SITES_DB, generate_username_variations, get_sites
from .ui import (
    HAS_RICH,
    console,
    display_categories_table,
    display_sites_catalog,
    print_banner,
    run_interactive_tui,
    run_scan_with_progress,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="n-osint",
        description=(
            "N-OSINT — Global Username Reconnaissance & OSINT Scanner across 195+ "
            "social networks and platforms worldwide (Created by Dem1)."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python n_osint.py                           # Launch interactive TUI menu (default: English)\n"
            "  python n_osint.py -l ru                     # Launch interactive TUI menu in Russian\n"
            "  python n_osint.py -l tg                     # Launch interactive TUI menu in Tajik (Тоҷикӣ)\n"
            "  python n_osint.py durov                     # Search @durov across all platforms\n"
            "  python n_osint.py torvalds -c social dev    # Search only in social & dev categories\n"
            "  python n_osint.py mrbeast -s X Instagram TikTok Telegram Steam\n"
            "  python n_osint.py nickname --variations -o reports/\n"
        ),
    )

    parser.add_argument(
        "usernames",
        nargs="*",
        help="One or more usernames to search (omit to open interactive TUI menu)",
    )
    parser.add_argument(
        "-l",
        "--lang",
        choices=["en", "ru", "tg"],
        default="en",
        help="Interface language: 'en' (English, default), 'ru' (Русский), 'tg' (Тоҷикӣ)",
    )
    parser.add_argument(
        "-i",
        "--interactive",
        action="store_true",
        help="Launch interactive TUI mode with menu",
    )
    parser.add_argument(
        "-c",
        "--category",
        nargs="+",
        metavar="CAT",
        help="Filter by categories: " + ", ".join(CATEGORIES.keys()),
    )
    parser.add_argument(
        "-s",
        "--site",
        nargs="+",
        metavar="SITE",
        help="Search only specific sites (e.g. -s X Instagram TikTok Threads Telegram Steam)",
    )
    parser.add_argument(
        "--list-sites",
        action="store_true",
        help="Display full catalog of all supported social networks and platforms",
    )
    parser.add_argument(
        "--list-categories",
        action="store_true",
        help="Display list of platform categories",
    )
    parser.add_argument(
        "-v",
        "--variations",
        action="store_true",
        help="Automatically check common username variations (nick_, _nick, nick.official, etc.)",
    )
    parser.add_argument(
        "-t",
        "--timeout",
        type=float,
        default=10.0,
        help="HTTP request timeout in seconds (default: 10.0)",
    )
    parser.add_argument(
        "-n",
        "--concurrency",
        type=int,
        default=45,
        help="Max concurrent async requests (default: 45)",
    )
    parser.add_argument(
        "--proxy",
        type=str,
        default=None,
        help="Use HTTP/SOCKS proxy (e.g. http://127.0.0.1:8080)",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default=None,
        help="Directory to automatically save reports (TXT, JSON, CSV, HTML)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show not-found profiles and WAF/timeout errors in real time",
    )
    parser.add_argument(
        "--no-SSL-check",
        action="store_true",
        help="Disable SSL certificate verification",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"N-OSINT v{__version__} by Dem1 ({len(SITES_DB)} platforms)",
    )
    return parser


def main(argv: List[str] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    set_lang(args.lang)

    if args.list_categories:
        print_banner()
        display_categories_table()
        return 0

    if args.list_sites:
        print_banner()
        display_sites_catalog()
        return 0

    # Launch interactive TUI if no usernames passed or -i specified
    if args.interactive or not args.usernames:
        try:
            run_interactive_tui()
        except KeyboardInterrupt:
            print(f"\n[!] {t('interrupted')}")
        return 0

    print_banner()

    sites = get_sites(categories=args.category, site_names=args.site)
    if not sites:
        if HAS_RICH:
            console.print(f"[bold red][!] {t('no_sites_matched')}[/bold red]")
        else:
            print(f"[!] {t('no_sites_matched')}")
        return 1

    target_usernames: List[str] = []
    for raw_u in args.usernames:
        clean_u = raw_u.strip().lstrip("@")
        if not clean_u:
            continue
        if args.variations:
            for var in generate_username_variations(clean_u):
                if var not in target_usernames:
                    target_usernames.append(var)
        else:
            target_usernames.append(clean_u)

    scanner = NOSINTScanner(
        timeout=args.timeout,
        concurrency=args.concurrency,
        proxy=args.proxy,
        verify_ssl=not args.no_SSL_check,
    )

    for username in target_usernames:
        try:
            results: List[ScanResult] = run_scan_with_progress(
                scanner=scanner,
                username=username,
                sites=sites,
                verbose=args.verbose,
            )
            if args.output:
                out_dir = Path(args.output)
                out_dir.mkdir(parents=True, exist_ok=True)
                safe_u = "".join(c if c.isalnum() or c in "._-" else "_" for c in username)
                ts = time.strftime("%Y%m%d_%H%M%S")
                base = f"{safe_u}_{ts}"
                export_txt(results, out_dir / f"{base}.txt", username)
                export_json(results, out_dir / f"{base}.json", username)
                export_csv(results, out_dir / f"{base}.csv")
                export_html(results, out_dir / f"{base}.html", username)
                if HAS_RICH:
                    console.print(
                        f"[bold green][✔] {t('reports_saved_title')}:[/bold green] {out_dir.resolve()}"
                    )
                else:
                    print(f"[+] {t('reports_saved_title')}: {out_dir.resolve()}")
        except KeyboardInterrupt:
            print(f"\n[!] {t('interrupted')}")
            return 130

    return 0


if __name__ == "__main__":
    sys.exit(main())
